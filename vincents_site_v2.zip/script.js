
// script.js - small helpers
document.addEventListener('DOMContentLoaded', function(){
  // nothing fancy for now
});
